
import { GoogleGenAI } from "@google/genai";

export async function getStepByStepSolution(question: string, answer: number) {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are a friendly Math Tutor. Explain the step-by-step logic to solve this math problem: ${question}. The correct answer is ${answer}. Keep the explanation brief, fun, and use bullet points or short sentences. Focus on mental shortcuts if possible.`,
      config: {
        temperature: 0.7,
        maxOutputTokens: 400,
        thinkingConfig: { thinkingBudget: 0 },
      }
    });
    
    // The .text property is a getter that returns the extracted string.
    return response.text || "I'm a bit stumped, but keep trying!";
  } catch (error) {
    console.error("Gemini Explanation Error:", error);
    return "The Math Wizard is resting. Try to solve it using your amazing brain!";
  }
}

export async function getCustomMathTrick(topic: string) {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Provide one clever mental math trick or shortcut for this topic: "${topic}". Include a clear example. Keep it under 100 words.`,
      config: {
        temperature: 1,
        maxOutputTokens: 300,
        thinkingConfig: { thinkingBudget: 0 },
      }
    });
    return response.text || "Mastering patterns is the key to math magic!";
  } catch (error) {
    console.error("Gemini Trick Error:", error);
    return "Keep practicing to find your own patterns! Every expert was once a beginner.";
  }
}
