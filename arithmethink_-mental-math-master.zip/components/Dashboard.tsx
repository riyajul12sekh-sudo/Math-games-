import React from 'react';
import { Link } from 'react-router-dom';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer } from 'recharts';
import { UserProfile, GameMode } from '../types';

interface DashboardProps {
  profile: UserProfile;
}

const Dashboard: React.FC<DashboardProps> = ({ profile }) => {
  const chartData = [
    { subject: 'Speed', A: profile.stats.skills.speed || 50, fullMark: 100 },
    { subject: 'Accuracy', A: profile.stats.skills.accuracy || 50, fullMark: 100 },
    { subject: 'Logic', A: profile.stats.skills.logic || 50, fullMark: 100 },
    { subject: 'Memory', A: profile.stats.skills.memory || 50, fullMark: 100 },
  ];

  // Mapping strictly to the screenshot labels and icons
  const gameTypes = [
    { mode: GameMode.ADDITION, icon: '🏰', label: 'CASTLE BUILDER', color: 'bg-[#5eead4]' }, // Teal
    { mode: GameMode.SUBTRACTION, icon: '⚔️', label: 'SLIME SLAYER', color: 'bg-[#60a5fa]' }, // Blue
    { mode: GameMode.MULTIPLICATION, icon: '🔋', label: 'VOLT MULTIPLY', color: 'bg-[#fb923c]' }, // Orange
    { mode: GameMode.DIVISION, icon: '🍕', label: 'PIZZA PARTY', color: 'bg-[#fb7185]' }, // Rose
    { mode: GameMode.UNITS, icon: '🛸', label: 'SPACE CARGO', color: 'bg-[#a3e635]' }, // Lime
    { mode: GameMode.SEQUENCE, icon: '🧶', label: 'CODE BREAKER', color: 'bg-[#818cf8]' }, // Indigo
    { mode: GameMode.COMPARISON, icon: '🆚', label: 'VALUE HERO', color: 'bg-[#facc15]' }, // Yellow
    { mode: GameMode.MIXED, icon: '🌪️', label: 'TURBO MIX', color: 'bg-[#22d3ee]' }, // Cyan
    { mode: 'DUAL', icon: '👑', label: 'CROWN CLASH', color: 'bg-[#c084fc]', path: '/dual' }, // Purple
  ];

  return (
    <div className="space-y-12 py-4 animate-in fade-in slide-in-from-bottom duration-700 max-w-2xl mx-auto pb-12">
      {/* Centered Profile Card */}
      <section className="gaming-card p-4 sm:p-6 relative overflow-hidden">
        <div className="gaming-inner p-8 sm:p-12 flex flex-col items-center text-center space-y-6">
          <div className="w-20 h-20 bg-[#064e3b] border-4 border-[#042f24] rounded-2xl flex items-center justify-center text-5xl shadow-2xl -mt-16 sm:-mt-20">
             🦁
          </div>
          
          <div className="space-y-2">
            <h1 className="text-4xl sm:text-5xl font-black text-white tracking-tight drop-shadow-lg">Hi, {profile.name}!</h1>
            <div className="flex items-center justify-center gap-2">
              <span className="text-[#10b981] font-black text-xs tracking-widest uppercase">Rank:</span>
              <span className="bg-[#064e3b] text-[#10b981] px-3 py-1 rounded-full text-[10px] font-black border-2 border-[#10b981]/30 uppercase">LVL {profile.stats.level}</span>
            </div>
          </div>
          
          <div className="w-full space-y-2">
            <div className="flex justify-between text-[10px] font-black text-[#10b981] uppercase tracking-widest italic px-1">
              <span>Goal Progress</span>
              <span>{profile.stats.totalSolved % profile.dailyGoal}/{profile.dailyGoal}</span>
            </div>
            <div className="progress-bar-slim p-1 overflow-hidden">
               <div 
                 className="h-full bg-[#10b981] rounded-full transition-all duration-1000 shadow-[0_0_8px_rgba(16,185,129,0.4)]"
                 style={{ width: `${Math.max(2, Math.min(100, (profile.stats.totalSolved % profile.dailyGoal) / profile.dailyGoal * 100))}%` }}
               />
            </div>
          </div>
        </div>
      </section>

      {/* Choose Quest Title */}
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-[#064e3b] border-4 border-[#042f24] rounded-xl flex items-center justify-center text-2xl">🎮</div>
          <h2 className="text-3xl font-black text-[#064e3b] uppercase tracking-tight">Choose Quest</h2>
        </div>
        
        <div className="grid grid-cols-2 gap-5">
          {gameTypes.map((game) => (
            <Link 
              key={game.label}
              to={game.path || `/play/${game.mode}`}
              className="quest-btn p-4 group"
            >
              <div className={`${game.color} icon-strip group-hover:scale-[1.02] transition-transform`}>
                <span className="text-4xl filter drop-shadow-[2px_2px_1px_rgba(0,0,0,0.3)]">{game.icon}</span>
              </div>
              <span className="font-black text-[#10b981] text-[10px] tracking-widest uppercase leading-tight text-center">
                {game.label}
              </span>
            </Link>
          ))}
        </div>
      </div>

      {/* Brain Power Section */}
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-[#064e3b] border-4 border-[#042f24] rounded-xl flex items-center justify-center text-2xl">🧠</div>
          <h2 className="text-3xl font-black text-[#064e3b] uppercase tracking-tight">Brain Power</h2>
        </div>
        
        <div className="gaming-card p-4 sm:p-6">
          <div className="gaming-inner p-6" style={{ height: '350px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="80%" data={chartData}>
                <PolarGrid stroke="#10b981" strokeOpacity={0.2} />
                <PolarAngleAxis 
                  dataKey="subject" 
                  tick={{ fill: '#10b981', fontWeight: 800, fontSize: 10, letterSpacing: '0.1em' }} 
                />
                <Radar
                  name="Stats"
                  dataKey="A"
                  stroke="#10b981"
                  strokeWidth={3}
                  fill="#10b981"
                  fillOpacity={0.4}
                  dot={{ r: 4, fill: '#fff', stroke: '#10b981', strokeWidth: 2 }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;