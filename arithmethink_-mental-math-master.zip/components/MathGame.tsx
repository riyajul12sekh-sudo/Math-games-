import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { UserProfile, GameMode, MathProblem, Difficulty } from '../types';
import { getStepByStepSolution } from '../geminiService';

interface MathGameProps {
  profile: UserProfile;
  onStatsUpdate: (stats: Partial<UserProfile['stats']>) => void;
}

const MathGame: React.FC<MathGameProps> = ({ profile, onStatsUpdate }) => {
  const { mode } = useParams<{ mode: string }>();
  const navigate = useNavigate();
  const [problem, setProblem] = useState<MathProblem | null>(null);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);
  const [timer, setTimer] = useState(30);
  const [sessionStreak, setSessionStreak] = useState(0);
  const [difficultyLevel, setDifficultyLevel] = useState(1);
  const [solution, setSolution] = useState<string | null>(null);
  const [loadingSolution, setLoadingSolution] = useState(false);
  
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const selectedAnswerRef = useRef<number | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const isMounted = useRef(true);

  useEffect(() => {
    isMounted.current = true;
    return () => { isMounted.current = false; };
  }, []);

  const resumeAudio = async () => {
    if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
      await audioCtxRef.current.resume();
    }
  };

  const playSound = async (type: 'success' | 'error' | 'timeup') => {
    if (!profile.soundEnabled) return;
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      await resumeAudio();
      
      const ctx = audioCtxRef.current;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      const now = ctx.currentTime;

      if (type === 'success') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, now);
        osc.frequency.exponentialRampToValueAtTime(659.25, now + 0.1);
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.2, now + 0.05);
        gain.gain.linearRampToValueAtTime(0, now + 0.3);
        osc.start(now);
        osc.stop(now + 0.3);
      } else if (type === 'error') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(150, now);
        osc.frequency.exponentialRampToValueAtTime(70, now + 0.2);
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.1, now + 0.05);
        gain.gain.linearRampToValueAtTime(0, now + 0.3);
        osc.start(now);
        osc.stop(now + 0.3);
      } else if (type === 'timeup') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(440, now);
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.05, now + 0.02);
        gain.gain.linearRampToValueAtTime(0, now + 0.1);
        osc.start(now);
        osc.stop(now + 0.1);
      }
    } catch (e) {
      console.warn("Audio play failed", e);
    }
  };

  const generateProblem = useCallback(() => {
    let baseRange = 10;
    if (profile.ageGroup === Difficulty.TEEN) baseRange = 30;
    if (profile.ageGroup === Difficulty.ADULT) baseRange = 80;
    
    const level = difficultyLevel;
    const range = baseRange + (level * 4);
    
    let activeMode = mode as GameMode;
    if (mode === GameMode.MIXED) {
      const modes = [
        GameMode.ADDITION, GameMode.SUBTRACTION, GameMode.MULTIPLICATION, 
        GameMode.DIVISION, GameMode.UNITS, GameMode.SEQUENCE, 
        GameMode.COMPARISON, GameMode.PERCENTAGE, GameMode.SQUARES
      ];
      activeMode = modes[Math.floor(Math.random() * modes.length)];
    }

    let question = "";
    let answer = 0;
    let unitLabel = "";
    let options: number[] = [];

    switch (activeMode) {
      case GameMode.SQUARES:
        const sqBase = Math.floor(Math.random() * (level + 5)) + 2;
        question = `${sqBase}²`;
        answer = sqBase * sqBase;
        break;

      case GameMode.PERCENTAGE:
        const pctTargets = [10, 20, 25, 50, 100];
        const pct = pctTargets[Math.floor(Math.random() * pctTargets.length)];
        const total = (Math.floor(Math.random() * 10) + 1) * 20;
        question = `${pct}% of ${total}`;
        answer = (pct / 100) * total;
        break;

      case GameMode.COMPARISON:
        const compStyle = Math.floor(Math.random() * 3); 
        if (compStyle === 0) {
          const v1 = Math.floor(Math.random() * range) + 5;
          const v2 = Math.floor(Math.random() * range) + 5;
          const isLarger = Math.random() > 0.5;
          question = `Which is ${isLarger ? 'LARGER' : 'SMALLER'}: ${v1} or ${v2}?`;
          answer = isLarger ? Math.max(v1, v2) : Math.min(v1, v2);
          options = [v1, v2];
        } else {
          const a = Math.floor(Math.random() * 10) + 2;
          const b = Math.floor(Math.random() * 10) + 2;
          const c = Math.floor(Math.random() * 10) + 2;
          const val1 = a + b;
          const val2 = c * 2;
          question = `Which is LARGER: (${a} + ${b}) or (${c} x 2)?`;
          answer = Math.max(val1, val2);
          options = [val1, val2];
        }
        break;

      case GameMode.SEQUENCE:
        const seqType = Math.floor(Math.random() * 3);
        const start = Math.floor(Math.random() * 10) + 1;
        if (seqType === 0) {
          const diff = Math.floor(Math.random() * 5) + 1;
          question = `${start}, ${start + diff}, ${start + diff * 2}, ?`;
          answer = start + diff * 3;
        } else if (seqType === 1) {
          const diff = Math.floor(Math.random() * 4) + 2;
          const sStart = start + diff * 4;
          question = `${sStart}, ${sStart - diff}, ${sStart - diff * 2}, ?`;
          answer = sStart - diff * 3;
        } else {
          const factor = 2;
          question = `${start}, ${start * factor}, ${start * factor * 2}, ?`;
          answer = start * factor * 3;
        }
        break;

      case GameMode.UNITS:
        const conversionTypes = [
          { from: 'km', to: 'm', factor: 1000 },
          { from: 'kg', to: 'g', factor: 1000 },
          { from: 'L', to: 'mL', factor: 1000 },
          { from: 'doz', to: 'pcs', factor: 12 },
        ];
        const selected = conversionTypes[Math.floor(Math.random() * conversionTypes.length)];
        const isForward = Math.random() > 0.5;
        let bVal = Math.floor(Math.random() * (level + 5)) + 1;
        if (isForward) {
          question = `${bVal} ${selected.from} = ? ${selected.to}`;
          answer = bVal * selected.factor;
          unitLabel = ` ${selected.to}`;
        } else {
          const tVal = bVal * selected.factor;
          question = `${tVal} ${selected.to} = ? ${selected.from}`;
          answer = bVal;
          unitLabel = ` ${selected.from}`;
        }
        break;

      case GameMode.MULTIPLICATION:
        const m1 = Math.floor(Math.random() * (5 + level)) + 2;
        const m2 = Math.floor(Math.random() * (5 + level)) + 2;
        question = `${m1} × ${m2}`;
        answer = m1 * m2;
        break;

      case GameMode.DIVISION:
        const d2 = Math.floor(Math.random() * (5 + level)) + 2;
        const dAns = Math.floor(Math.random() * (5 + level)) + 2;
        const d1 = d2 * dAns;
        question = `${d1} ÷ ${d2}`;
        answer = dAns;
        break;

      case GameMode.SUBTRACTION:
        let s1 = Math.floor(Math.random() * range) + 1;
        let s2 = Math.floor(Math.random() * range) + 1;
        if (s1 < s2) [s1, s2] = [s2, s1];
        question = `${s1} - ${s2}`;
        answer = s1 - s2;
        break;

      default: // ADDITION
        const a1 = Math.floor(Math.random() * range) + 1;
        const a2 = Math.floor(Math.random() * range) + 1;
        question = `${a1} + ${a2}`;
        answer = a1 + a2;
    }

    if (options.length === 0) {
      options = [answer];
      while (options.length < 4) {
        let offset = Math.floor(Math.random() * 11) - 5;
        if (offset === 0) offset = 2;
        const w = answer + offset;
        if (!options.includes(w) && w >= 0) options.push(w);
      }
    }
    options.sort(() => Math.random() - 0.5);
    
    if (isMounted.current) {
      setProblem({ id: Math.random().toString(), question, answer, options, difficulty: level, unitLabel, mode: activeMode });
      setFeedback(null);
      setSolution(null);
      setTimer(Math.max(6, (profile.ageGroup === Difficulty.KIDS ? 25 : 15) - level));
    }
  }, [mode, difficultyLevel, profile.ageGroup]);

  useEffect(() => {
    generateProblem();
  }, [generateProblem]);

  useEffect(() => {
    if (profile.zenMode) return;
    if (timer > 0 && !feedback) {
      timerRef.current = setTimeout(() => {
        if (isMounted.current) setTimer(t => t - 1);
      }, 1000);
      if (timer <= 3 && timer > 0) playSound('timeup');
    } else if (timer === 0 && !feedback) {
      handleAnswer(null);
    }
    return () => { if (timerRef.current) clearTimeout(timerRef.current); };
  }, [timer, feedback, profile.zenMode]);

  const handleAnswer = (val: number | null) => {
    if (feedback !== null || !isMounted.current) return;
    selectedAnswerRef.current = val;
    const isCorrect = val === problem?.answer;
    
    setFeedback(isCorrect ? 'correct' : 'wrong');
    playSound(isCorrect ? 'success' : 'error');
    if (navigator.vibrate) navigator.vibrate(isCorrect ? [40] : [100, 50, 100]);
    
    if (isCorrect) {
      const newStreak = sessionStreak + 1;
      setSessionStreak(newStreak);
      if (newStreak % 5 === 0) setDifficultyLevel(l => l + 1);
      
      onStatsUpdate({
        totalSolved: profile.stats.totalSolved + 1,
        correctAnswers: profile.stats.correctAnswers + 1,
        streak: Math.max(profile.stats.streak, newStreak),
        skills: {
          ...profile.stats.skills,
          speed: Math.min(100, profile.stats.skills.speed + (timer > 10 ? 3 : 1)),
          accuracy: Math.min(100, profile.stats.skills.accuracy + 2)
        }
      });
    } else {
      setSessionStreak(0);
      onStatsUpdate({ totalSolved: profile.stats.totalSolved + 1 });
    }

    setTimeout(() => {
      if (isMounted.current) generateProblem();
    }, 1200);
  };

  const handleShowSolution = async () => {
    if (!problem || loadingSolution) return;
    setLoadingSolution(true);
    const text = await getStepByStepSolution(problem.question, problem.answer);
    if (isMounted.current) {
      setSolution(text);
      setLoadingSolution(false);
    }
  };

  if (!problem) return null;

  const modeIconMap: Record<string, string> = {
    [GameMode.ADDITION]: '🏰',
    [GameMode.SUBTRACTION]: '⚔️',
    [GameMode.MULTIPLICATION]: '🔋',
    [GameMode.DIVISION]: '🍕',
    [GameMode.UNITS]: '🛸',
    [GameMode.SEQUENCE]: '🧶',
    [GameMode.COMPARISON]: '🆚',
    [GameMode.MIXED]: '🌪️',
  };

  return (
    <div className="max-w-xl mx-auto space-y-8 animate-in slide-in-from-bottom duration-500 pb-20 pt-4" onClick={resumeAudio}>
      <div className="flex items-center justify-between px-2">
        <button onClick={() => navigate('/')} className="bg-white border-2 border-[#064e3b] px-6 py-2 text-emerald-900 font-black rounded-xl shadow-[4px_4px_0_0_#064e3b] active:translate-y-1 active:shadow-none transition-all">
          EXIT
        </button>
        <div className="flex gap-3">
          <div className="bg-orange-400 border-4 border-[#064e3b] px-4 py-2 rounded-2xl font-black text-white shadow-[4px_4px_0_0_#064e3b]">
             🔥 {sessionStreak}
          </div>
          <div className="bg-emerald-400 border-4 border-[#064e3b] px-4 py-2 rounded-2xl font-black text-white shadow-[4px_4px_0_0_#064e3b]">
             LVL {difficultyLevel}
          </div>
        </div>
      </div>

      <div className="bg-white border-[6px] border-[#064e3b] rounded-[3rem] p-8 sm:p-10 shadow-[16px_16px_0_0_#064e3b] relative overflow-hidden">
        {!profile.zenMode && (
          <div className="absolute top-0 left-0 w-full h-4 bg-emerald-100">
            <div 
              className={`h-full transition-all duration-1000 border-r-4 border-emerald-900 ${timer < 4 ? 'bg-rose-500 animate-pulse' : 'bg-emerald-500'}`} 
              style={{ width: `${(timer / (profile.ageGroup === Difficulty.KIDS ? 25 : 15)) * 100}%` }}
            />
          </div>
        )}

        <div className="text-center py-12 relative">
          <div className="absolute top-0 right-0 text-7xl opacity-10 pointer-events-none animate-pulse">
            {modeIconMap[problem.mode] || '🦁'}
          </div>
          
          <h2 className="text-4xl sm:text-6xl font-black text-[#064e3b] tracking-tighter tabular-nums mb-4 drop-shadow-sm">
            {problem.question}
          </h2>
          <div className="text-emerald-700 font-black uppercase text-xs tracking-[0.2em] italic">
            <span>{profile.zenMode ? 'NO PRESSURE' : 'QUICK! SELECT!'}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-5 mt-6">
          {problem.options.map((opt, i) => (
            <button
              key={i}
              disabled={feedback !== null}
              onClick={() => handleAnswer(opt)}
              className={`
                quest-btn py-8 sm:py-12 rounded-[2rem] font-black text-3xl sm:text-5xl border-4
                ${feedback === null ? 'bg-white text-[#064e3b] border-[#042f24] hover:bg-emerald-50' : ''}
                ${feedback === 'correct' && opt === problem.answer ? 'bg-[#10b981] text-white border-white scale-105 z-10 shadow-none' : ''}
                ${feedback === 'wrong' && opt === selectedAnswerRef.current ? 'bg-rose-500 text-white border-white shadow-none' : ''}
                ${feedback === 'wrong' && opt === problem.answer ? 'bg-[#10b981] text-white animate-bounce shadow-none' : ''}
                ${feedback !== null && opt !== problem.answer && opt !== selectedAnswerRef.current ? 'opacity-20 grayscale shadow-none' : ''}
              `}
            >
              {opt}{problem.unitLabel}
            </button>
          ))}
        </div>
      </div>

      <div className="flex flex-col gap-4">
        <button 
          onClick={handleShowSolution}
          disabled={loadingSolution}
          className="bg-blue-500 border-4 border-[#1e3a8a] py-6 rounded-3xl font-black text-white flex items-center justify-center gap-3 text-2xl shadow-[8px_8px_0_0_#1e3a8a] active:translate-y-1 active:shadow-none transition-all"
        >
          {loadingSolution ? '🤖 SCANNING...' : '💡 ASK THE ROBOT'}
        </button>
        
        {solution && (
          <div className="bg-white border-4 border-[#064e3b] p-8 rounded-[2.5rem] shadow-[8px_8px_0_0_#064e3b] animate-in zoom-in duration-300">
            <h4 className="font-black text-[#064e3b] mb-3 flex items-center gap-3 text-xl">
               <span className="text-3xl">🤖</span> LOGIC FEED:
            </h4>
            <div className="text-emerald-900 font-bold leading-relaxed whitespace-pre-wrap">{solution}</div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MathGame;