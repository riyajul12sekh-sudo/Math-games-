
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { UserProfile } from '../types';

interface HeaderProps {
  profile: UserProfile;
  onThemeToggle: () => void;
  onSoundToggle: () => void;
}

const Header: React.FC<HeaderProps> = ({ profile, onThemeToggle, onSoundToggle }) => {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="sticky top-0 z-50 bg-[#10b981] border-b-4 border-[#064e3b] px-4 py-3 shadow-xl">
      <div className="container mx-auto flex items-center justify-between gap-4 max-w-5xl px-2">
        <Link to="/" className="flex items-center gap-2 group shrink-0">
          <div className="bg-[#064e3b] border-2 border-[#042f24] w-10 h-10 rounded-xl flex items-center justify-center font-black text-xl text-white shadow-md group-hover:scale-105 transition-transform">
            ∑
          </div>
        </Link>

        <nav className="flex items-center gap-4 sm:gap-8 overflow-x-auto no-scrollbar">
          <Link to="/tricks" className={`text-[10px] sm:text-xs font-black tracking-[0.15em] uppercase transition-all flex items-center gap-1 ${isActive('/tricks') ? 'text-white' : 'text-[#064e3b] hover:text-white'}`}>
            Hacks ⚡
          </Link>
          <Link to="/badges" className={`text-[10px] sm:text-xs font-black tracking-[0.15em] uppercase transition-all flex items-center gap-1 ${isActive('/badges') ? 'text-white' : 'text-[#064e3b] hover:text-white'}`}>
            Badges 🏆
          </Link>
          <Link to="/profile" className={`text-[10px] sm:text-xs font-black tracking-[0.15em] uppercase transition-all flex items-center gap-1 ${isActive('/profile') ? 'text-white' : 'text-[#064e3b] hover:text-white'}`}>
            Profile 👤
          </Link>
        </nav>
        
        <div className="flex items-center gap-2 shrink-0">
          <button 
            onClick={onSoundToggle}
            className="w-10 h-10 bg-[#064e3b] border-2 border-[#042f24] rounded-xl flex items-center justify-center text-xl text-white shadow-md active:translate-y-0.5 transition-all hover:bg-[#0d2a21]"
          >
            {profile.soundEnabled ? '🔊' : '🔇'}
          </button>
          <button 
            onClick={onThemeToggle}
            className="w-10 h-10 bg-[#020617] border-2 border-[#000] rounded-xl flex items-center justify-center text-xl text-yellow-400 shadow-md active:translate-y-0.5 transition-all hover:bg-black"
          >
            {profile.theme === 'light' ? '🌙' : '☀️'}
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;